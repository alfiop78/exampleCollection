import zipcelx from './zipcelx';

global.zipcelx = zipcelx;
